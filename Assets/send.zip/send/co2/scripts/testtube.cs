﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class testtube : MonoBehaviour
{
    //public Animator colour;

    // Start is called before the first frame update
    void Start()
    {
        SetComponent();

    }

    void SetComponent()
    {
        transform.position = new Vector3(-14.89f, -3309.30f, -5f);
        transform.localScale = new Vector3(6.748f, 6.6647f, 6.7479f);

    }

    // Update is called once per frame
    void Update()
    {

    }
}
